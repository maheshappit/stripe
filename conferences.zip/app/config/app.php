'custom' => [
    'csv_file_path' => public_path('products.csv'),
],