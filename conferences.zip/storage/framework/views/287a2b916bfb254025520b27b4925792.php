
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>



<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('admin.postVerifyOTP')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="otp">OTP</label>
                    <input id="otp" type="text" class="form-control<?php echo e($errors->has('otp') ? ' is-invalid' : ''); ?>" name="otp" value="" autofocus placeholder="<?php echo e(__('OTP')); ?>">
                    <?php if($errors->has('otp')): ?>
                        <div class="invalid-feedback">
                            <?php echo e($errors->first('otp')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->has('otp')): ?>
                    <span class="help-block mt-4">
                        <strong><?php echo e($errors->first('otp')); ?></strong>
                    </span>
                <?php endif; ?>

                <?php if(session('otp_sent_success')): ?>
                    <div class="text-success mt-4">
                        <?php echo e(session('otp_sent_success')); ?>

                    </div>
                <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-success">Verify</button>
                <button type="submit" class="btn btn-info ml-2" formaction="<?php echo e(route('admin.resndOTP')); ?>" >Resend</button>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\conferences\resources\views/admin/verify_otp.blade.php ENDPATH**/ ?>