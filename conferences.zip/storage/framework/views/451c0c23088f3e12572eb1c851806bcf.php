<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('User Login')); ?></div>

                <div class="card-body">
                <form action="<?php echo e(route('user.loginWithOTP')); ?>" id="loginform" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                     
                      

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">

                            <!-- <a href="<?php echo e(route('admin.login')); ?>" class="btn btn-danger">
                                    <?php echo e(__('Admin Login')); ?>

</a> -->
                                
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <!-- <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?> -->
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('user.loginWithOTP')); ?>" id="loginform" method="post">
        <?php echo csrf_field(); ?>

        <?php if(session('status')): ?>
            <div class="alert alert-success m-t-10">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="form-group mb-3">
            <input type="email" name="email" class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                   placeholder="<?php echo app('translator')->get('auth.email'); ?>" value="<?php echo e(old('email')); ?>" autofocus>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
        
        

        <div class="row">
            <!-- <div class="col-sm-6">
                <div class="checkbox icheck">
                    <label>
                        <div class="icheckbox_flat-green" aria-checked="false" aria-disabled="false" style="position: relative;">
                            <input  type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>  name="remember_me" id="remember_me" class="flat-red"  style="position: absolute; opacity: 0;">
                            <ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins>
                        </div>
                        <?php echo app('translator')->get('auth.rememberMe'); ?>
                    </label>
                </div>
            </div> -->

            <!-- <div class="col-sm-6 text-right">
                <a href="#" id="to-recover"><?php echo app('translator')->get('app.forgotPassword'); ?></a>
            </div> -->

            <!-- /.col -->
            <div class="col-sm-12 mt-4">
                <button type="submit" id="save-form" class="btn btn-primary btn-block"><?php echo app('translator')->get('auth.login'); ?></button>
            </div>
            <!-- /.col -->
        </div>
      

    </form>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\conferences\resources\views/auth/login.blade.php ENDPATH**/ ?>