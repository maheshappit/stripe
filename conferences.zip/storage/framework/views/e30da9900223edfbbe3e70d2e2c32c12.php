

<?php $__env->startSection('dashboard-content'); ?>

<head>
<script>
        $(document).ready(function() {

            $('#myForm').submit(function(e) {
                e.preventDefault();

                var formData = $(this).serialize();

                $.ajax({
                    type: 'POST',
                    url: '<?php echo e(route('conferencedetails.save')); ?>',

                    data: formData,
                    success: function(response) {

                        console.log(formData);

                        if (response.status_code == '200') {
                            toastr.success(response.message);
                            $('#name').val('');
                            $('#email').val('');
                            $('#article').val('');
                            $('#email').val('');
                            $('#country').val('');

                            

                        }
                    },
                    error: function(xhr, status, error) {

                        var errors = xhr.responseJSON.errors;
                        handleValidationErrors(errors);
                    },
                });
            });

            function handleValidationErrors(errors) {
                // Display validation errors as toasts
                for (var field in errors) {
                    if (errors.hasOwnProperty(field)) {
                        toastr.error(errors[field][0]);
                    }
                }
            }
        });
    </script>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

</head>

<div class="item">
        <div class="card-body">

            <form id="myForm">
                <?php echo csrf_field(); ?>


                <div class="form-row">
                    <h4> Create Conference </h4>
                   
                </div>

                <div class="form-row">

                <label for="exampleFormControlInput1">Conference</label>

                <select class="custom-select" name="conference">
                    <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option   value="<?php echo e($code->name); ?>"><?php echo e($code->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </select>
                   

                </div>

               
                <div class="form-row">
                    <label for="exampleFormControlInput1">Name</label>
                    <input type="text" name="name" id="name" class="form-control">
                </div>

                <div class="form-row">
                    <label for="exampleFormControlInput1">Email address</label>
                    <input type="email" name="email" id="email" class="form-control">
                </div>

                <div class="form-row">
                    <label for="exampleFormControlInput1">Article </label>
                    <input type="text" name="article" id="article" class="form-control">
                </div>

                <div class="form-row">
                    <label for="exampleFormControlInput1">Country </label>
                    <input type="text" name="country" id="country" class="form-control">
                </div>

                

                <br>
                <div class="row">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>


            </form>

        </div>
</div>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\conferences\resources\views/conferences/create.blade.php ENDPATH**/ ?>